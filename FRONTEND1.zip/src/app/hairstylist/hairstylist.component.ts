import { Component, OnInit } from '@angular/core';
export interface Hairstylist {
  id: number;
  name: string;
}
//import { Hero } from './hero';

export const HAIRSTYLIST: Hairstylist[] = [
  { id: 12, name: 'Dr. Nice' },
  { id: 13, name: 'Bombasto' },
  { id: 14, name: 'Celeritas' },
  { id: 15, name: 'Magneta' },
  { id: 16, name: 'RubberMan' },
  { id: 17, name: 'Dynama' },
  { id: 18, name: 'Dr. IQ' },
  { id: 19, name: 'Magma' },
  { id: 20, name: 'Tornado' }
];
@Component({
  selector: 'app-hairstylist',
  templateUrl: './hairstylist.component.html',
  styleUrls: ['./hairstylist.component.css']
})
export class HairstylistComponent implements OnInit {
  public hairstylist = { id: 1, name: 'Iuliana' };
  constructor() { }

  ngOnInit(): void {
  }

}
