import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HairstylistComponent } from '../../hairstylist/hairstylist.component';

const routes: Routes = [

  {
    path: '', redirectTo: 'hairstylist',
    pathMatch:'full'
  }  , {
  path: 'hairstylist',
  component:HairstylistComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HairStylistRoutingModule { }
