import { TestBed } from '@angular/core/testing';

import { HairstylistsService } from './hairstylists.service';

describe('HairstylistsService', () => {
  let service: HairstylistsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HairstylistsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
