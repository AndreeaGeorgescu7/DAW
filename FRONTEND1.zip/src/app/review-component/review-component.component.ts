import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-review-component',
  templateUrl: './review-component.component.html',
  styleUrls: ['./review-component.component.css']
})
export class ReviewComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  namehairstylist = new FormControl('');
  namebs = new FormControl('');
  delay = new FormControl('');
  rate = new FormControl('');
  attitude = new FormControl('');
  negative = new FormControl('');
  positive = new FormControl('');

}
