﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace TestDAW1.Model
{
    public class Role : IdentityRole<int>
    {
        public ICollection<UserRole> UserRoles { get; set; }
    }
}
