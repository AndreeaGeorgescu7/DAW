﻿namespace TestDAW1
{
    internal class HairStylistyRepo
    {
    }
}