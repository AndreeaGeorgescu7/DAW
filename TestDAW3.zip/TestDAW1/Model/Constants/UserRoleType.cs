﻿namespace TestDAW1.Model.Constants
{
    public class UserRoleType
    {
        public static readonly string Admin = "Admin";
        public static readonly string User = "User";
    }
}
