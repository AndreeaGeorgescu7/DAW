﻿using System.Net;

namespace TestDAW1.Entities.DataTransferObject
{
    public class CreateHairStylistDTO
    {

       
            public string Name { get; set; }
            public PersonalData PersonalData{ get; set; }
        
    }
}
