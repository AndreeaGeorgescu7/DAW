﻿namespace TestDAW1.Entities.DataTransferObject
{
    public class CreateHairServiceDTO
    {

        public string Name { get; set; }
        public float Price { get; set; }

        public int HairStylistId { get; set; }
    }
}
