﻿namespace TestDAW1.Entities.DataTransferObject.UserDTO
{
    public class LoginUserDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
