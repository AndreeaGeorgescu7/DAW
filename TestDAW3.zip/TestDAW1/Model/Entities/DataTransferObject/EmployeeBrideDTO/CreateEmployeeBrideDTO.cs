﻿using System.Collections.Generic;
using TestDAW1.Entities;

namespace TestDAW1.Model.Entities.DataTransferObject.EmployeeBrideDTO
{
    public class CreateEmployeeBrideDTO
    {
        public int HairStylistId { get; set; }

        public int BridePackageId { get; set; }

    }
}
